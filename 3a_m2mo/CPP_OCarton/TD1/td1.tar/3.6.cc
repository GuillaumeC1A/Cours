#include <iostream>

using namespace std;

long long n;

bool isPrime(long long a) {
        for (long long j = 2; j < sqrt(a) + 1; j++) {
            if (a % j == 0) {
                return false;
            }
        }
        return true;
} 

int main() {
    cout << "Entrez un nombre et appuyez sur [Enter]: ";

    cin >> n;

    long long sqrt_n = sqrt(n);
    for(long long i = 2; i <= sqrt_n; i++) {
        if(n==1) break;
        if (isPrime(i)) {
            cout << i << endl;

            if (n % i == 0) {
                cout << i << endl;
                n = n / (long long)i;
            }
        }
    }

    //à finir pour le revoir, pour une raison inconnue il n'essaye pa
}