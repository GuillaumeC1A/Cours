#include <iostream>

using namespace std;
    
int main() {

    int x;

    cout << "Entrez un nombre et appuyez sur [Enter]: ";

    cin >> a;

    cout << "Entrez un second nombre et appuyez sur [Enter]: ";

    cin >> b;


    if (a % b == 0) {

      cout << "est divisible";

    } else {

      cout << "n'est pas divisible";

    }

    cout << endl;

}