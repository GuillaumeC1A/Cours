#include <iostream>

int LaSolution(int x) {
    return x+42;
}